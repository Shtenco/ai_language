# AI Lang Prototype 🧠

> **Natural Language → DSL → AST → Semantic Graph → Code**  
> Powered by **Grok API (xAI)**  · Generates **Python / C / Rust / Solidity / Kotlin**

```
[English / Russian text]
        ↓  Grok API
      [DSL]
        ↓  Tokenizer → Parser
      [AST]
        ↓  Semantic Graph
  [Code Generator]
        ↓
Python / C / Rust / Solidity / Kotlin
        ↓
  Run / Compile
```

---

## Install

```bash
pip install ai-lang-prototype
```

---

## Quick Start

### 1. Set your Grok API key

```bash
# Option A — environment variable (recommended)
export GROK_API_KEY="xai-YOUR_KEY_HERE"

# Option B — save to config file
ailang config --set-key xai-YOUR_KEY_HERE

# Option C — pass inline
ailang --key xai-YOUR_KEY_HERE --nl "compute the cube of 4"
```

Get your key at → **[https://console.x.ai](https://console.x.ai)**

---

### 2. Interactive REPL

```bash
ailang repl
```

Type tasks in **Russian or English** — Grok translates them into DSL, then all pipeline stages run automatically.

REPL commands:

| Command | Description |
|---|---|
| `:target python\|c\|rust\|solidity\|kotlin` | Switch target language |
| `:run` | Toggle Python auto-run |
| `:explain` | Toggle Grok explanation |
| `:dsl` | Show last generated DSL |
| `:ast` | Show AST as JSON |
| `:graph` | Show Semantic Graph |
| `:code` | Show last generated code |
| `:example N` | Load built-in example (1–5) |
| `:help` | Print help |
| `:exit` | Quit |

---

### 3. CLI Commands

```bash
# Natural language → Python → run + explain
ailang run --nl "вычисли факториал числа 6"
ailang run --nl "write a function that squares a number" --target rust

# Built-in examples (1–5)
ailang run --example 1 --target python
ailang run --example 3 --target c --compile-native

# Preset NL examples
ailang run --nl-example ru 0 --run
ailang run --nl-example en 2 --target kotlin

# Load DSL from file
ailang run --dsl my_program.dsl --target rust

# Save outputs
ailang run --example 1 --out demo.py --graph-json g.json --ast-json ast.json

# Show pipeline details
ailang run --example 2 --show-tokens --show-graph --show-ast

# List examples
ailang examples

# Show config / key info
ailang config --show
```

---

### 4. Python API

```python
from ailang import pipeline, nl_to_dsl, set_api_key

# Set key programmatically
set_api_key("xai-YOUR_KEY_HERE")

# Natural language → DSL → code
dsl = nl_to_dsl("compute the square of 9 and print the result")
result = pipeline(dsl, target="python", run=True)

print(result["code"])    # generated Python code
print(result["output"])  # execution output

# All targets
for target in ("python", "c", "rust", "solidity", "kotlin"):
    result = pipeline(dsl, target=target)
    print(f"\n── {target.upper()} ──")
    print(result["code"])
```

---

## DSL Reference

```
program <name>
let <var> = <arithmetic_expr>
func <name>(<arg1>, <arg2>):
    let <local> = <expr>
    return <expr>
let <result> = <funcname>(<arg1>, <arg2>)
print <var>
print "string literal"
if <condition>:
    <body>
else:
    <body>
repeat <N>:
    <body>
```

**Rules:**
- Indentation = 4 spaces
- No semicolons, no type declarations
- Arithmetic: `+`, `-`, `*`, `/`, `**`, `%`
- Comparisons: `>`, `<`, `>=`, `<=`, `==`, `!=`
- One expression per line

**Example:**

```
program Demo
let x = 10
let y = 20
func add(a, b):
    return a + b
let z = add(x, y)
print "sum="
print z
if z > 20:
    print "big"
else:
    print "small"
repeat 3:
    print z
```

---

## Supported Targets

| Target | Generator | Run | Native Compile |
|---|---|---|---|
| `python` | ✅ | ✅ (`--run`) | — |
| `c` | ✅ | — | ✅ (`gcc`) |
| `rust` | ✅ | — | ✅ (`rustc`) |
| `solidity` | ✅ | — | ✅ (`solc`) |
| `kotlin` | ✅ | — | ✅ (`kotlinc`) |

---

## Pipeline Stages

```
1. Tokenize   — lexical analysis, indent/dedent tracking
2. Parse      — recursive descent parser → AST nodes
3. Sem. Graph — entity graph (variables, functions, deps)
4. CodeGen    — target-specific emitter
5. Run/Compile — Python subprocess / native toolchain
6. Explain    — Grok explains the generated code (optional)
7. Self-debug — Grok fixes broken DSL on parse errors (auto)
```

---

## Config & Key Storage

```bash
# Save key to ~/.ailang/config.json
ailang config --set-key xai-YOUR_KEY_HERE

# Show current config
ailang config --show

# Clear key
ailang config --clear-key
```

Priority order:
1. `--key` CLI flag
2. `GROK_API_KEY` environment variable
3. `~/.ailang/config.json`

---

## License

MIT © 2024 Evgeniy Koshtenko

---

## 💙 Support the Project / Поддержать проект

If this project saved you time or inspired you — a small donation keeps development going.

**Ethereum (ETH / ERC-20):**
```
0x980Ddb04c54979b3Ed23df4a7DBc7049b7d0D686
```

**Bitcoin (BTC / Native SegWit):**
```
bc1q49rfm0p6qh6nlnm4az4yhhk9x82zfxwgtcnhvm
```

Every contribution — big or small — is genuinely appreciated. Thank you! 🙏

---

## Links

- **PyPI:** https://pypi.org/project/ai-lang-prototype
- **GitHub:** https://github.com/koshtenko/ai-lang-prototype
- **Grok API:** https://console.x.ai
- **Author:** Evgeniy Koshtenko — algorithmic trader & AI researcher
