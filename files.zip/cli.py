"""
CLI entry point — `ailang` command.

Sub-commands:
  ailang repl                  — interactive REPL
  ailang run  [options]        — run the pipeline once
  ailang examples              — list all built-in examples
  ailang config                — manage API key / config
  ailang donate                — show donation info
"""
from __future__ import annotations

import argparse
import json
import sys
import textwrap

from . import __version__
from .ast_nodes  import to_dict as ast_to_dict
from .codegen    import GENERATORS
from .config     import (
    clear_api_key, config_summary, get_api_key,
    save_api_key, set_api_key,
)
from .examples   import EXAMPLES, NL_EXAMPLES
from .grok       import detect_language, nl_to_dsl
from .pipeline   import pipeline
from .repl       import DONATE_BTC, DONATE_ETH, run_repl

_DONATE = f"""
  💙 Support the project / Поддержать проект:

  Ethereum (ETH / ERC-20):
    {DONATE_ETH}

  Bitcoin (BTC / Native SegWit):
    {DONATE_BTC}

  Thank you! / Спасибо! 🙏
"""


def main(argv=None):
    parser = _build_parser()
    args = parser.parse_args(argv)

    # ── Apply API key from --key flag (highest priority) ─────────────────────
    if hasattr(args, "key") and args.key:
        set_api_key(args.key)
        if hasattr(args, "func"):
            # also persist if --save-key requested
            pass

    if not hasattr(args, "func"):
        parser.print_help()
        return

    args.func(args)


# ─── SUB-COMMAND: repl ───────────────────────────────────────────────────────

def _cmd_repl(args):
    if args.key:
        set_api_key(args.key)
    run_repl()


# ─── SUB-COMMAND: run ────────────────────────────────────────────────────────

def _cmd_run(args):
    if args.key:
        set_api_key(args.key)

    # Verify key early
    key = get_api_key()
    if not key and (args.nl or args.nl_example or args.explain):
        _die(
            "❌ Grok API key not set.\n"
            "   export GROK_API_KEY=xai-...\n"
            "   ailang config --set-key xai-...\n"
            "   ailang run --key xai-... ..."
        )

    verbose  = not args.quiet
    dsl_src  = None
    lang     = "en"

    # ── Source selection ──────────────────────────────────────────────────────
    if args.example:
        ex = EXAMPLES.get(args.example)
        if ex is None:
            _die(f"❌ Unknown example {args.example}. Valid: {list(EXAMPLES)}")
        _p(verbose, f"\n📚 Example {args.example}: {ex['title']}")
        dsl_src = ex["dsl"]

    elif args.dsl:
        try:
            with open(args.dsl, "r", encoding="utf-8") as f:
                dsl_src = f.read()
        except FileNotFoundError:
            _die(f"❌ File not found: {args.dsl}")
        _p(verbose, f"\n📂 Loaded from: {args.dsl}")

    elif args.nl:
        lang    = detect_language(args.nl)
        dsl_src = nl_to_dsl(args.nl, verbose=verbose)
        _p(verbose, f"\n── Generated DSL ──\n{dsl_src}")

    elif args.nl_example:
        nl_lang, nl_idx_s = args.nl_example
        nl_idx = int(nl_idx_s)
        lang   = nl_lang
        pool   = NL_EXAMPLES.get(nl_lang, NL_EXAMPLES["en"])
        if nl_idx >= len(pool):
            _die(f"❌ Index {nl_idx} out of range for lang '{nl_lang}' (0–{len(pool)-1})")
        text    = pool[nl_idx]
        _p(verbose, f"\n📝 NL [{nl_lang}]: {text}")
        dsl_src = nl_to_dsl(text, verbose=verbose)
        _p(verbose, f"\n── Generated DSL ──\n{dsl_src}")

    else:
        parser_run_print_help()
        return

    if not dsl_src or not dsl_src.strip():
        _die("❌ Empty DSL source.")

    # ── Pipeline ──────────────────────────────────────────────────────────────
    result = pipeline(
        dsl_src,
        target      = args.target,
        run         = args.run,
        compile_nat = args.compile_native,
        graph_json  = args.graph_json or "",
        ast_json    = args.ast_json   or "",
        explain     = args.explain,
        lang        = lang,
        verbose     = verbose,
    )

    # ── Save code ─────────────────────────────────────────────────────────────
    if args.out and "code" in result:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(result["code"])
        _p(verbose, f"\n💾 Code saved → {args.out}")

    # ── Extras ────────────────────────────────────────────────────────────────
    if args.show_tokens and "tokens" in result:
        print("\n── Tokens ──────────────────────────────────")
        for tok in result["tokens"]:
            print(f"  {tok}")

    if args.show_graph and "graph" in result:
        print("\n── Semantic Graph ──────────────────────────")
        print(result["graph"].summary())

    if args.show_ast and "ast" in result:
        print("\n── AST (JSON) ──────────────────────────────")
        print(json.dumps(ast_to_dict(result["ast"]), ensure_ascii=False, indent=2))

    if result.get("error"):
        print(f"\n⚠️  Error: {result['error']}", file=sys.stderr)
        sys.exit(1)


_run_help_printer = None  # filled below


def parser_run_print_help():
    if _run_help_printer:
        _run_help_printer()


# ─── SUB-COMMAND: examples ───────────────────────────────────────────────────

def _cmd_examples(_args):
    print("\n📚 Built-in DSL examples  (ailang run --example N)")
    for k, v in EXAMPLES.items():
        print(f"   {k}: {v['title']}")
    print("\n🇷🇺 NL RU presets  (ailang run --nl-example ru N)")
    for i, ex in enumerate(NL_EXAMPLES["ru"]):
        print(f"   {i}: {ex}")
    print("\n🇬🇧 NL EN presets  (ailang run --nl-example en N)")
    for i, ex in enumerate(NL_EXAMPLES["en"]):
        print(f"   {i}: {ex}")
    print()


# ─── SUB-COMMAND: config ─────────────────────────────────────────────────────

def _cmd_config(args):
    if args.set_key:
        save_api_key(args.set_key)
        set_api_key(args.set_key)
        k = args.set_key
        print(f"✅ API key saved: {k[:8]}...{k[-4:]}")
        return
    if args.clear_key:
        clear_api_key()
        print("✅ API key removed from config file.")
        return
    print(config_summary())


# ─── SUB-COMMAND: donate ─────────────────────────────────────────────────────

def _cmd_donate(_args):
    print(_DONATE)


# ─── Parser builder ──────────────────────────────────────────────────────────

def _build_parser() -> argparse.ArgumentParser:
    global _run_help_printer

    root = argparse.ArgumentParser(
        prog="ailang",
        description="AI Lang Prototype · Grok Edition",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""
        examples:
          ailang repl
          ailang run --example 1 --target python --run
          ailang run --nl "вычисли куб числа 4" --run --explain
          ailang run --nl "compute square of 9" --target rust
          ailang run --nl-example ru 0 --run
          ailang run --example 3 --target c --compile-native
          ailang run --example 1 --graph-json g.json --ast-json ast.json
          ailang config --set-key xai-YOUR_KEY
          ailang config --show
          ailang examples
          ailang donate
        """),
    )
    root.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    subs = root.add_subparsers(dest="command")

    # ── repl ──────────────────────────────────────────────────────────────────
    p_repl = subs.add_parser("repl", help="Interactive REPL")
    p_repl.add_argument("--key", metavar="KEY", help="Grok API key (session only)")
    p_repl.set_defaults(func=_cmd_repl)

    # ── run ───────────────────────────────────────────────────────────────────
    p_run = subs.add_parser(
        "run",
        help="Run the full pipeline once",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _run_help_printer = p_run.print_help

    src = p_run.add_mutually_exclusive_group()
    src.add_argument("--example",    type=int, metavar="N",
                     help="Built-in example (1–5)")
    src.add_argument("--dsl",        type=str, metavar="FILE",
                     help="Load DSL from file")
    src.add_argument("--nl",         type=str, metavar="TEXT",
                     help="Natural language input (RU or EN) → DSL via Grok")
    src.add_argument("--nl-example", nargs=2, metavar=("LANG", "N"),
                     help="Preset NL: --nl-example ru 0  or  --nl-example en 2")

    p_run.add_argument("--key",            metavar="KEY",
                       help="Grok API key (session only; overrides env/config)")
    p_run.add_argument("--target",         default="python",
                       choices=list(GENERATORS),
                       help="Target language (default: python)")
    p_run.add_argument("--run",            action="store_true",
                       help="Execute generated Python code")
    p_run.add_argument("--compile-native", action="store_true",
                       help="Compile with gcc / rustc / kotlinc / solc")
    p_run.add_argument("--explain",        action="store_true",
                       help="Ask Grok to explain generated code")
    p_run.add_argument("--out",            metavar="FILE",
                       help="Save generated code to file")
    p_run.add_argument("--graph-json",     metavar="FILE",
                       help="Save semantic graph JSON")
    p_run.add_argument("--ast-json",       metavar="FILE",
                       help="Save AST JSON")
    p_run.add_argument("--show-tokens",    action="store_true")
    p_run.add_argument("--show-graph",     action="store_true")
    p_run.add_argument("--show-ast",       action="store_true")
    p_run.add_argument("--quiet",          action="store_true",
                       help="Suppress verbose output")
    p_run.set_defaults(func=_cmd_run)

    # ── examples ──────────────────────────────────────────────────────────────
    p_ex = subs.add_parser("examples", help="List all built-in examples")
    p_ex.set_defaults(func=_cmd_examples)

    # ── config ────────────────────────────────────────────────────────────────
    p_cfg = subs.add_parser("config", help="Manage API key and settings")
    cfg_grp = p_cfg.add_mutually_exclusive_group()
    cfg_grp.add_argument("--set-key",   metavar="KEY",
                         help="Save Grok API key to ~/.ailang/config.json")
    cfg_grp.add_argument("--clear-key", action="store_true",
                         help="Remove saved API key")
    cfg_grp.add_argument("--show",      action="store_true",
                         help="Show current config (default)")
    p_cfg.set_defaults(func=_cmd_config)

    # ── donate ────────────────────────────────────────────────────────────────
    p_don = subs.add_parser("donate", help="Show donation addresses")
    p_don.set_defaults(func=_cmd_donate)

    return root


def _p(verbose: bool, msg: str):
    if verbose:
        print(msg)


def _die(msg: str):
    print(msg, file=sys.stderr)
    sys.exit(1)
