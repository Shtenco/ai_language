"""
Tests for AI Lang Prototype pipeline.
All tests run WITHOUT calling the Grok API.
"""
import json
import pytest
import sys
import os

# Make sure the src layout is importable during testing
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from ailang.tokenizer import tokenize
from ailang.parser    import Parser
from ailang.ast_nodes import to_dict, LetNode, FuncNode, IfNode, RepeatNode
from ailang.semantic  import build_graph
from ailang.codegen   import GENERATORS
from ailang.runner    import run_python
from ailang.examples  import EXAMPLES


# ─── helpers ──────────────────────────────────────────────────────────────────

def parse(dsl: str):
    return Parser(tokenize(dsl)).parse()


# ─── Tokenizer ────────────────────────────────────────────────────────────────

class TestTokenizer:
    def test_basic_let(self):
        toks = tokenize("let x = 42")
        types = [t[0] for t in toks]
        assert "LET" in types

    def test_func_token(self):
        toks = tokenize("func add(a, b):\n    return a + b")
        types = [t[0] for t in toks]
        assert "FUNC" in types
        assert "RETURN" in types

    def test_indent_dedent(self):
        src = "if x > 0:\n    print x\n"
        toks = tokenize(src)
        types = [t[0] for t in toks]
        assert "INDENT" in types
        assert "DEDENT" in types

    def test_skip_comments(self):
        toks = tokenize("# comment\nlet x = 1")
        types = [t[0] for t in toks]
        assert "LET" in types

    def test_eof(self):
        toks = tokenize("")
        assert toks[-1][0] == "EOF"


# ─── Parser / AST ─────────────────────────────────────────────────────────────

class TestParser:
    def test_program_name(self):
        prog = parse("program MyTest\nlet x = 1")
        assert prog.name == "MyTest"

    def test_let_node(self):
        prog = parse("let x = 10\nlet y = 20")
        assert any(isinstance(n, LetNode) and n.var == "x" for n in prog.body)
        assert any(isinstance(n, LetNode) and n.var == "y" for n in prog.body)

    def test_func_node(self):
        prog = parse("func add(a, b):\n    return a + b")
        assert any(isinstance(n, FuncNode) and n.name == "add" for n in prog.body)

    def test_func_args(self):
        prog = parse("func mul(x, y):\n    return x * y")
        fn = next(n for n in prog.body if isinstance(n, FuncNode))
        assert fn.args == ["x", "y"]

    def test_if_else(self):
        prog = parse("if z > 0:\n    print z\nelse:\n    print \"neg\"")
        assert any(isinstance(n, IfNode) for n in prog.body)

    def test_repeat(self):
        prog = parse("repeat 5:\n    print \"hi\"")
        assert any(isinstance(n, RepeatNode) for n in prog.body)

    def test_ast_to_dict(self):
        prog = parse("program T\nlet a = 1")
        d = to_dict(prog)
        assert d["kind"] == "Program"
        assert d["name"] == "T"
        assert isinstance(d["body"], list)

    def test_all_builtin_examples_parse(self):
        """All 5 built-in examples must parse without error."""
        for n, ex in EXAMPLES.items():
            prog = parse(ex["dsl"])
            assert prog is not None, f"Example {n} failed to parse"


# ─── Semantic Graph ────────────────────────────────────────────────────────────

class TestSemanticGraph:
    def test_nodes_created(self):
        prog = parse("let x = 1\nlet y = 2")
        g = build_graph(prog)
        assert "var:x" in g.nodes
        assert "var:y" in g.nodes

    def test_function_node(self):
        prog = parse("func sq(n):\n    return n * n")
        g = build_graph(prog)
        assert "func:sq" in g.nodes

    def test_defines_edges(self):
        prog = parse("let a = 10")
        g = build_graph(prog)
        labels = [e.label for e in g.edges]
        assert "defines" in labels

    def test_uses_edge(self):
        prog = parse("let a = 5\nlet b = a + 1")
        g = build_graph(prog)
        labels = [e.label for e in g.edges]
        assert "uses" in labels

    def test_to_dict(self):
        prog = parse("let x = 1")
        g = build_graph(prog)
        d = g.to_dict()
        assert "nodes" in d
        assert "edges" in d

    def test_summary_string(self):
        prog = parse("let x = 1")
        g = build_graph(prog)
        s = g.summary()
        assert "nodes" in s.lower() or "var:x" in s


# ─── Code Generators ──────────────────────────────────────────────────────────

_SIMPLE_DSL = "program T\nlet x = 3\nlet y = 4\nfunc add(a, b):\n    return a + b\nlet z = add(x, y)\nprint z"

class TestCodeGen:
    def _gen(self, target: str) -> str:
        prog = parse(_SIMPLE_DSL)
        return GENERATORS[target].generate(prog)

    def test_python_def(self):
        code = self._gen("python")
        assert "def add(" in code
        assert "print(" in code

    def test_python_let(self):
        code = self._gen("python")
        assert "x = 3" in code

    def test_c_include(self):
        code = self._gen("c")
        assert "#include <stdio.h>" in code

    def test_c_main(self):
        code = self._gen("c")
        assert "int main(" in code

    def test_c_double(self):
        code = self._gen("c")
        assert "double" in code

    def test_rust_fn(self):
        code = self._gen("rust")
        assert "fn main()" in code
        assert "fn add(" in code

    def test_rust_f64(self):
        code = self._gen("rust")
        assert "f64" in code

    def test_solidity_contract(self):
        code = self._gen("solidity")
        assert "contract T" in code
        assert "pragma solidity" in code

    def test_kotlin_fun(self):
        code = self._gen("kotlin")
        assert "fun main()" in code
        assert "fun add(" in code

    def test_kotlin_double(self):
        code = self._gen("kotlin")
        assert "Double" in code

    def test_all_examples_all_targets(self):
        """Every built-in example must produce non-empty code for every target."""
        for n, ex in EXAMPLES.items():
            prog = parse(ex["dsl"])
            for tname, gen in GENERATORS.items():
                code = gen.generate(prog)
                assert code.strip(), f"Example {n} → {tname} produced empty code"


# ─── Python Runner ────────────────────────────────────────────────────────────

class TestRunner:
    def test_run_hello(self):
        code = 'print("hello world")'
        out  = run_python(code)
        assert "hello world" in out

    def test_run_arithmetic(self):
        code = "x = 3 + 4\nprint(x)"
        out  = run_python(code)
        assert "7" in out

    def test_run_example1_python(self):
        ex   = EXAMPLES[1]
        prog = parse(ex["dsl"])
        code = GENERATORS["python"].generate(prog)
        out  = run_python(code)
        assert "30" in out      # z = add(10, 20)
        assert "big" in out     # z > 20

    def test_run_example3_circle(self):
        ex   = EXAMPLES[3]
        prog = parse(ex["dsl"])
        code = GENERATORS["python"].generate(prog)
        out  = run_python(code)
        assert "153" in out     # area ≈ 153.938
        assert "Large" in out

    def test_syntax_error_captured(self):
        out = run_python("def broken(:\n    pass")
        assert out  # something returned, not crash


# ─── Config (no API calls) ────────────────────────────────────────────────────

class TestConfig:
    def test_set_get_runtime(self):
        from ailang.config import set_api_key, get_api_key
        set_api_key("xai-testkey1234")
        assert get_api_key() == "xai-testkey1234"
        set_api_key("")  # reset

    def test_config_summary(self):
        from ailang.config import config_summary
        s = config_summary()
        assert "Config file" in s
