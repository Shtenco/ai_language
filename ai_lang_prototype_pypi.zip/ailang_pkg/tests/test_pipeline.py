"""Tests — NO Grok API calls needed."""
import json, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from ailang.tokenizer import tokenize
from ailang.parser    import Parser
from ailang.ast_nodes import to_dict, LetNode, FuncNode, IfNode, RepeatNode
from ailang.semantic  import build_graph
from ailang.codegen   import GENERATORS
from ailang.runner    import run_python
from ailang.examples  import EXAMPLES


def _parse(dsl):
    return Parser(tokenize(dsl)).parse()


class TestTokenizer:
    def test_let(self):          assert "LET"    in [t[0] for t in tokenize("let x = 1")]
    def test_func(self):         assert "FUNC"   in [t[0] for t in tokenize("func f(a):\n    return a")]
    def test_indent_dedent(self):
        types = [t[0] for t in tokenize("if x > 0:\n    print x\n")]
        assert "INDENT" in types and "DEDENT" in types
    def test_skip_comments(self):assert "LET"    in [t[0] for t in tokenize("# c\nlet x = 1")]
    def test_eof(self):          assert tokenize("")[-1][0] == "EOF"

class TestParser:
    def test_name(self):   assert _parse("program T\nlet x=1").name == "T"
    def test_let(self):    assert any(isinstance(n, LetNode) and n.var=="x" for n in _parse("let x=10").body)
    def test_func(self):   assert any(isinstance(n, FuncNode) and n.name=="add" for n in _parse("func add(a,b):\n    return a+b").body)
    def test_func_args(self):
        fn = next(n for n in _parse("func mul(x,y):\n    return x*y").body if isinstance(n, FuncNode))
        assert fn.args == ["x","y"]
    def test_if(self):     assert any(isinstance(n, IfNode)    for n in _parse("if z>0:\n    print z\nelse:\n    print \"n\"").body)
    def test_repeat(self): assert any(isinstance(n, RepeatNode) for n in _parse("repeat 5:\n    print \"hi\"").body)
    def test_ast_dict(self):
        d = to_dict(_parse("program T\nlet a=1"))
        assert d["kind"] == "Program" and d["name"] == "T"
    def test_all_examples(self):
        for n, ex in EXAMPLES.items():
            assert _parse(ex["dsl"]) is not None, f"Example {n} failed"

class TestSemanticGraph:
    def test_vars(self):
        g = build_graph(_parse("let x=1\nlet y=2"))
        assert "var:x" in g.nodes and "var:y" in g.nodes
    def test_func_node(self):
        assert "func:sq" in build_graph(_parse("func sq(n):\n    return n*n")).nodes
    def test_defines_edge(self):
        assert "defines" in [e.label for e in build_graph(_parse("let a=10")).edges]
    def test_uses_edge(self):
        assert "uses" in [e.label for e in build_graph(_parse("let a=5\nlet b=a+1")).edges]
    def test_to_dict(self):
        d = build_graph(_parse("let x=1")).to_dict()
        assert "nodes" in d and "edges" in d

class TestCodeGen:
    _DSL = "program T\nlet x=3\nfunc add(a,b):\n    return a+b\nlet z=add(x,x)\nprint z"

    def _gen(self, t): return GENERATORS[t].generate(_parse(self._DSL))
    def test_python(self):   assert "def add(" in self._gen("python")
    def test_c(self):        assert "int main(" in self._gen("c")
    def test_rust(self):     assert "fn main()" in self._gen("rust")
    def test_solidity(self): assert "contract T" in self._gen("solidity")
    def test_kotlin(self):   assert "fun main()" in self._gen("kotlin")
    def test_all_examples_all_targets(self):
        for n, ex in EXAMPLES.items():
            prog = _parse(ex["dsl"])
            for tname, gen in GENERATORS.items():
                assert gen.generate(prog).strip(), f"Example {n} → {tname} empty"

class TestRunner:
    def test_hello(self):    assert "hello" in run_python('print("hello")')
    def test_math(self):     assert "7"     in run_python("print(3+4)")
    def test_example1(self):
        code = GENERATORS["python"].generate(_parse(EXAMPLES[1]["dsl"]))
        out  = run_python(code)
        assert "30" in out and "big" in out
    def test_example3(self):
        code = GENERATORS["python"].generate(_parse(EXAMPLES[3]["dsl"]))
        assert "153" in run_python(code)

class TestConfig:
    def test_set_get(self):
        from ailang.config import set_api_key, get_api_key
        set_api_key("xai-test"); assert get_api_key() == "xai-test"; set_api_key("")
    def test_summary(self):
        from ailang.config import config_summary
        assert "Config file" in config_summary()
