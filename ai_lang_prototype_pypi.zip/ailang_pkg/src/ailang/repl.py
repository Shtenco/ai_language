"""Interactive REPL."""
from __future__ import annotations
import json

from .ast_nodes import to_dict as ast_to_dict
from .codegen   import GENERATORS
from .config    import config_summary, set_api_key
from .examples  import EXAMPLES, NL_EXAMPLES
from .grok      import detect_language, nl_to_dsl
from .pipeline  import pipeline

DONATE_ETH = "0x980Ddb04c54979b3Ed23df4a7DBc7049b7d0D686"
DONATE_BTC = "bc1q49rfm0p6qh6nlnm4az4yhhk9x82zfxwgtcnhvm"

_BANNER = f"""
╔══════════════════════════════════════════════════════════════════╗
║       AI Lang Prototype  ·  Grok Edition  ·  REPL  v1.0         ║
╠══════════════════════════════════════════════════════════════════╣
║  Введите задание на русском или английском языке.                ║
╠══════════════════════════════════════════════════════════════════╣
║  :target python|c|rust|solidity|kotlin  — сменить таргет         ║
║  :run      — toggle Python auto-run                              ║
║  :explain  — toggle Grok объяснения                              ║
║  :key <k>  — задать API-ключ (сессия)                            ║
║  :config   — статус ключа                                        ║
║  :dsl  :ast  :graph  :code  — последний результат                ║
║  :example N  :nlru N  :nlen N  — встроенные примеры              ║
║  :list     — все примеры                                         ║
║  :donate   — поддержать проект                                   ║
║  :exit     — выход                                               ║
╚══════════════════════════════════════════════════════════════════╝
"""

_DONATE = f"""
  💙 Поддержать проект / Support the project:

  Ethereum (ETH / ERC-20):
    {DONATE_ETH}

  Bitcoin (BTC / Native SegWit):
    {DONATE_BTC}

  Спасибо! / Thank you! 🙏
"""


def run_repl():
    print(_BANNER)
    print(config_summary()); print()
    target = "python"; auto_run = True; auto_ex = False; last: dict = {}

    while True:
        try:
            inp = input(f"[{target}] 🧠 > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!"); break
        if not inp: continue
        lo = inp.lower()

        if lo in (":exit", ":quit", "quit", "exit"):
            print("Bye!"); break
        if lo in (":help", ":h"):
            print(_BANNER); continue
        if lo == ":donate":
            print(_DONATE); continue
        if lo == ":config":
            print(config_summary()); continue
        if lo.startswith(":key "):
            set_api_key(inp[5:].strip()); print("✅ Key set"); continue
        if lo.startswith(":target "):
            t = lo[8:].strip()
            if t in GENERATORS: target = t; print(f"✅ Target → {t}")
            else: print(f"❌ Available: {list(GENERATORS)}")
            continue
        if lo == ":run":
            auto_run = not auto_run; print(f"✅ Auto-run: {'ON' if auto_run else 'OFF'}"); continue
        if lo == ":explain":
            auto_ex = not auto_ex; print(f"✅ Explain: {'ON' if auto_ex else 'OFF'}"); continue
        if lo == ":dsl":   _show("DSL",  last.get("_dsl")); continue
        if lo == ":code":  _show("Code", last.get("code")); continue
        if lo == ":ast":
            print(json.dumps(ast_to_dict(last["ast"]), ensure_ascii=False, indent=2) if "ast" in last else "(none)"); continue
        if lo == ":graph":
            print(last["graph"].summary() if "graph" in last else "(none)"); continue
        if lo == ":list":  _list(); continue

        if lo.startswith(":example "):
            try: n = int(lo[9:]); ex = EXAMPLES[n]
            except: print(f"❌ Valid: {list(EXAMPLES)}"); continue
            print(f"\n📚 Example {n}: {ex['title']}"); _show("DSL", ex["dsl"])
            last = pipeline(ex["dsl"], target=target, run=auto_run and target=="python",
                            explain=auto_ex, lang="en"); continue

        for prefix, lang_code in ((":nlru ", "ru"), (":nlen ", "en")):
            if lo.startswith(prefix):
                try: idx = int(lo[6:]); text = NL_EXAMPLES[lang_code][idx]
                except: print("❌ Index out of range"); break
                flag = "🇷🇺" if lang_code == "ru" else "🇬🇧"
                print(f"\n{flag} {text}\n")
                try: dsl = nl_to_dsl(text)
                except RuntimeError as e: print(f"❌ {e}"); break
                _show("DSL", dsl)
                last = pipeline(dsl, target=target, run=auto_run and target=="python",
                                explain=auto_ex, lang=lang_code)
                break
        else:
            lang = detect_language(inp)
            try: dsl = nl_to_dsl(inp)
            except RuntimeError as e: print(f"❌ {e}"); continue
            _show("Generated DSL", dsl)
            last = pipeline(dsl, target=target, run=auto_run and target=="python",
                            explain=auto_ex, lang=lang)
        print()


def _show(title, content):
    if content: print(f"\n── {title} {'─'*(48-len(title))}\n{content}\n{'─'*50}")
    else: print(f"(no {title} yet)")

def _list():
    print("\n📚 DSL examples  (:example N)")
    for k, v in EXAMPLES.items(): print(f"  {k}: {v['title']}")
    print("\n🇷🇺 NL RU  (:nlru N)")
    for i, e in enumerate(NL_EXAMPLES["ru"]): print(f"  {i}: {e}")
    print("\n🇬🇧 NL EN  (:nlen N)")
    for i, e in enumerate(NL_EXAMPLES["en"]): print(f"  {i}: {e}")
    print()
