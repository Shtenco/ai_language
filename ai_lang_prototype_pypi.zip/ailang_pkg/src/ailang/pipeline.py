"""Full pipeline: DSL → tokens → AST → semantic graph → code → run/compile."""
from __future__ import annotations
import json as _json
from typing import Any, Dict

from .ast_nodes import to_dict as ast_to_dict
from .codegen   import GENERATORS
from .grok      import grok_explain, grok_self_debug
from .parser    import Parser
from .runner    import compile_native, run_python
from .semantic  import build_graph
from .tokenizer import tokenize


def pipeline(
    dsl_source:  str,
    target:      str  = "python",
    run:         bool = False,
    compile_nat: bool = False,
    graph_json:  str  = "",
    ast_json:    str  = "",
    explain:     bool = False,
    lang:        str  = "en",
    verbose:     bool = True,
    auto_debug:  bool = True,
) -> Dict[str, Any]:
    """
    Run the full AI Lang pipeline.

    Returns dict with keys:
      tokens, ast, graph, code, output, native_output, explanation, error, _dsl
    """
    R: Dict[str, Any] = {"_dsl": dsl_source}

    _v(verbose, "\n📋 Step 1 · Tokenize")
    tokens = tokenize(dsl_source)
    R["tokens"] = tokens
    _v(verbose, f"   {len(tokens)} tokens")

    _v(verbose, "🌳 Step 2 · Parse → AST")
    try:
        ast = Parser(tokens).parse()
    except SyntaxError as exc:
        R["error"] = str(exc)
        _v(verbose, f"   ❌ {exc}")
        if auto_debug:
            _v(verbose, "🔧 Grok self-debug...")
            fixed = grok_self_debug(dsl_source, str(exc))
            _v(verbose, f"\n── Fixed DSL ──\n{fixed}\n")
            return pipeline(fixed, target=target, run=run, compile_nat=compile_nat,
                            graph_json=graph_json, ast_json=ast_json,
                            explain=explain, lang=lang, verbose=verbose, auto_debug=False)
        return R

    _v(verbose, f"   '{ast.name}' — {len(ast.body)} top-level nodes")
    R["ast"] = ast

    if ast_json:
        with open(ast_json, "w", encoding="utf-8") as f:
            _json.dump(ast_to_dict(ast), f, ensure_ascii=False, indent=2)
        _v(verbose, f"   💾 AST → {ast_json}")

    _v(verbose, "🕸️  Step 3 · Semantic Graph")
    g = build_graph(ast)
    R["graph"] = g
    _v(verbose, f"   {len(g.nodes)} nodes, {len(g.edges)} edges")

    if graph_json:
        with open(graph_json, "w", encoding="utf-8") as f:
            _json.dump(g.to_dict(), f, ensure_ascii=False, indent=2)
        _v(verbose, f"   💾 Graph → {graph_json}")

    _v(verbose, f"⚙️  Step 4 · Generate {target.upper()}")
    gen = GENERATORS.get(target)
    if gen is None:
        R["error"] = f"Unknown target: {target!r}. Available: {list(GENERATORS)}"
        return R

    code = gen.generate(ast)
    R["code"] = code

    if verbose:
        bar = "═" * 60
        print(f"\n{bar}\n  ▶ {target.upper()}\n{bar}\n{code}\n{bar}\n")

    if run and target == "python":
        _v(verbose, "🚀 Step 5 · Run Python")
        out = run_python(code)
        R["output"] = out
        if verbose:
            print(f"{'─'*40}\n{out}\n{'─'*40}\n")

    if compile_nat and target != "python":
        _v(verbose, f"🔨 Step 5 · Compile ({target})")
        nat = compile_native(code, target)
        R["native_output"] = nat
        _v(verbose, nat)

    if explain:
        _v(verbose, "💬 Step 6 · Grok explanation")
        expl = grok_explain(code, lang=lang)
        R["explanation"] = expl
        if verbose: print(f"\n{expl}\n")

    return R


def _v(verbose: bool, msg: str):
    if verbose: print(msg)
