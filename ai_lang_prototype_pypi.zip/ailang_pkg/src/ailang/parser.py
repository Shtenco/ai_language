"""Recursive descent parser: TokenList → AST."""
from __future__ import annotations

from typing import Any, List, Optional, Tuple

from .ast_nodes import (
    AstNode, ExprNode, FuncNode, IfNode, LetNode,
    PrintNode, ProgramNode, RepeatNode, ReturnNode,
)
from .tokenizer import TokenList

Token = Tuple[str, Any]


class Parser:
    def __init__(self, tokens: TokenList):
        self._tokens = [t for t in tokens if t[0] != "NEWLINE"]
        self._pos = 0

    def _peek(self) -> Token:
        return self._tokens[self._pos] if self._pos < len(self._tokens) else ("EOF", None)

    def _consume(self, expected: str = "") -> Token:
        tok = self._peek()
        if expected and tok[0] != expected:
            raise SyntaxError(f"Expected {expected!r}, got {tok[0]!r} (val={tok[1]!r})")
        self._pos += 1
        return tok

    def parse(self) -> ProgramNode:
        name = "Main"
        if self._peek()[0] == "PROGRAM":
            _, name = self._consume("PROGRAM")
        return ProgramNode(name=name, body=self._parse_block())

    def _parse_block(self) -> List[AstNode]:
        nodes: List[AstNode] = []
        while self._peek()[0] not in ("EOF", "DEDENT", "ELSE"):
            n = self._parse_stmt()
            if n is not None:
                nodes.append(n)
        return nodes

    def _parse_stmt(self) -> Optional[AstNode]:
        tt, tv = self._peek()
        if tt == "EOF":   return None
        if tt == "LET":   self._consume(); return LetNode(var=tv[0], expr=tv[1])
        if tt == "RETURN":self._consume(); return ReturnNode(expr=tv)
        if tt == "PRINT": self._consume(); return PrintNode(expr=tv)
        if tt == "EXPR":  self._consume(); return ExprNode(expr=tv)
        if tt in ("INDENT","DEDENT"): self._consume(); return None
        if tt == "FUNC":
            self._consume()
            name, args = tv
            return FuncNode(name=name, args=args, body=self._parse_indented())
        if tt == "IF":
            self._consume()
            then_b = self._parse_indented()
            else_b: List[AstNode] = []
            if self._peek()[0] == "ELSE":
                self._consume()
                else_b = self._parse_indented()
            return IfNode(cond=tv, then_body=then_b, else_body=else_b)
        if tt == "REPEAT":
            self._consume()
            return RepeatNode(count=tv, body=self._parse_indented())
        self._consume()
        return None

    def _parse_indented(self) -> List[AstNode]:
        if self._peek()[0] == "INDENT":   self._consume()
        body = self._parse_block()
        if self._peek()[0] == "DEDENT":   self._consume()
        return body
