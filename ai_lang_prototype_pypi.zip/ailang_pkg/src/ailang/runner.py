"""Python runner + native compiler bridge."""
from __future__ import annotations
import os, subprocess, sys, tempfile

def run_python(code: str) -> str:
    with tempfile.NamedTemporaryFile(suffix=".py", mode="w", encoding="utf-8", delete=False) as f:
        f.write(code); fname = f.name
    try:
        r = subprocess.run([sys.executable, fname], capture_output=True, text=True, timeout=10)
        out = r.stdout
        if r.returncode != 0: out += f"\n[stderr]\n{r.stderr}"
        return out.strip()
    except subprocess.TimeoutExpired: return "[TIMEOUT 10s]"
    except Exception as e: return f"[ERROR] {e}"
    finally:
        try: os.unlink(fname)
        except: pass

def compile_native(code: str, target: str) -> str:
    exts = {"c": ".c", "rust": ".rs", "kotlin": ".kt", "solidity": ".sol"}
    ext  = exts.get(target, ".txt")
    with tempfile.NamedTemporaryFile(suffix=ext, mode="w", encoding="utf-8", delete=False) as f:
        f.write(code); src = f.name
    try:
        if target == "c":
            binary = src.replace(ext, "")
            r = subprocess.run(["gcc", src, "-o", binary, "-lm"], capture_output=True, text=True, timeout=30)
            if r.returncode != 0: return f"[gcc ERROR]\n{r.stderr}"
            return f"[gcc OK]\n{subprocess.run([binary], capture_output=True, text=True, timeout=5).stdout}"
        if target == "rust":
            binary = src.replace(ext, "")
            r = subprocess.run(["rustc", src, "-o", binary], capture_output=True, text=True, timeout=60)
            if r.returncode != 0: return f"[rustc ERROR]\n{r.stderr}"
            return f"[rustc OK]\n{subprocess.run([binary], capture_output=True, text=True, timeout=5).stdout}"
        if target == "kotlin":
            jar = src.replace(ext, ".jar")
            r = subprocess.run(["kotlinc", src, "-include-runtime", "-d", jar], capture_output=True, text=True, timeout=120)
            if r.returncode != 0: return f"[kotlinc ERROR]\n{r.stderr}"
            return f"[kotlinc OK]\n{subprocess.run(['java', '-jar', jar], capture_output=True, text=True, timeout=10).stdout}"
        if target == "solidity":
            r = subprocess.run(["solc", "--bin", src], capture_output=True, text=True, timeout=30)
            return f"[solc]\n{r.stdout or r.stderr}"
        return f"[No compiler for: {target}]"
    finally:
        try: os.unlink(src)
        except: pass
