"""Semantic graph: entities + dependency edges from AST."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List

from .ast_nodes import AstNode, FuncNode, IfNode, LetNode, PrintNode, ProgramNode, RepeatNode


@dataclass
class SemNode:
    id: str; kind: str; props: Dict[str, Any] = field(default_factory=dict)

@dataclass
class SemEdge:
    src: str; dst: str; label: str


class SemanticGraph:
    def __init__(self):
        self.nodes: Dict[str, SemNode] = {}
        self.edges: List[SemEdge] = []

    def add_node(self, n: SemNode):   self.nodes[n.id] = n
    def add_edge(self, s, d, l):      self.edges.append(SemEdge(src=s, dst=d, label=l))

    def to_dict(self):
        return {
            "nodes": [{"id": n.id, "kind": n.kind, "props": n.props} for n in self.nodes.values()],
            "edges": [{"src": e.src, "dst": e.dst, "label": e.label} for e in self.edges],
        }

    def summary(self) -> str:
        lines = [f"Semantic Graph — {len(self.nodes)} nodes, {len(self.edges)} edges:"]
        for n in self.nodes.values():
            lines.append(f"  [{n.kind:10s}] {n.id}  {n.props}")
        lines.append("")
        for e in self.edges:
            lines.append(f"  {e.src}  ──{e.label}──▶  {e.dst}")
        return "\n".join(lines)


def build_graph(program: ProgramNode) -> SemanticGraph:
    g = SemanticGraph()
    pid = f"program:{program.name}"
    g.add_node(SemNode(id=pid, kind="block", props={"name": program.name}))

    def walk(nodes: List[AstNode], parent: str):
        for node in nodes:
            if isinstance(node, LetNode):
                nid = f"var:{node.var}"
                g.add_node(SemNode(id=nid, kind="variable", props={"name": node.var, "expr": node.expr}))
                g.add_edge(parent, nid, "defines")
                for ref in re.findall(r"\b([a-zA-Z_]\w*)\b", node.expr):
                    if f"var:{ref}"  in g.nodes: g.add_edge(nid, f"var:{ref}", "uses")
                    elif f"func:{ref}" in g.nodes: g.add_edge(nid, f"func:{ref}", "calls")
            elif isinstance(node, FuncNode):
                nid = f"func:{node.name}"
                g.add_node(SemNode(id=nid, kind="function", props={"name": node.name, "args": node.args}))
                g.add_edge(parent, nid, "defines")
                walk(node.body, nid)
            elif isinstance(node, IfNode):
                nid = f"if:{id(node)}"
                g.add_node(SemNode(id=nid, kind="block", props={"cond": node.cond}))
                g.add_edge(parent, nid, "contains")
                walk(node.then_body, nid); walk(node.else_body, nid)
            elif isinstance(node, RepeatNode):
                nid = f"repeat:{id(node)}"
                g.add_node(SemNode(id=nid, kind="block", props={"count": node.count}))
                g.add_edge(parent, nid, "contains")
                walk(node.body, nid)
            elif isinstance(node, PrintNode):
                for ref in re.findall(r"\b([a-zA-Z_]\w*)\b", node.expr):
                    if f"var:{ref}" in g.nodes: g.add_edge(parent, f"var:{ref}", "uses")

    walk(program.body, pid)
    return g
