"""
AI Lang Prototype
=================
Natural Language (RU/EN) → DSL → AST → Semantic Graph → Code
Powered by Grok API (xAI).  Generates Python / C / Rust / Solidity / Kotlin.

Quick start:
    from ailang import pipeline, nl_to_dsl, set_api_key
    set_api_key("xai-YOUR_KEY_HERE")
    dsl    = nl_to_dsl("compute the square of 9 and print the result")
    result = pipeline(dsl, target="python", run=True)
    print(result["code"])
    print(result["output"])

GitHub : https://github.com/Shtenco/ai_language
Donate ETH : 0x980Ddb04c54979b3Ed23df4a7DBc7049b7d0D686
Donate BTC : bc1q49rfm0p6qh6nlnm4az4yhhk9x82zfxwgtcnhvm
"""

__version__ = "1.0.0"
__author__  = "Evgeniy Koshtenko"
__license__ = "MIT"

DONATE_ETH = "0x980Ddb04c54979b3Ed23df4a7DBc7049b7d0D686"
DONATE_BTC = "bc1q49rfm0p6qh6nlnm4az4yhhk9x82zfxwgtcnhvm"

from .config   import get_api_key, load_config, save_config, set_api_key  # noqa: F401
from .grok     import grok_call, grok_explain, grok_self_debug, nl_to_dsl  # noqa: F401
from .pipeline import pipeline                                              # noqa: F401

__all__ = [
    "__version__", "DONATE_ETH", "DONATE_BTC",
    "set_api_key", "get_api_key", "save_config", "load_config",
    "grok_call", "nl_to_dsl", "grok_explain", "grok_self_debug",
    "pipeline",
]
