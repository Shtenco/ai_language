from .python_gen   import PythonGen
from .c_gen        import CGen
from .rust_gen     import RustGen
from .solidity_gen import SolidityGen
from .kotlin_gen   import KotlinGen

GENERATORS = {
    "python":   PythonGen(),
    "c":        CGen(),
    "rust":     RustGen(),
    "solidity": SolidityGen(),
    "kotlin":   KotlinGen(),
}
__all__ = ["GENERATORS", "PythonGen", "CGen", "RustGen", "SolidityGen", "KotlinGen"]
