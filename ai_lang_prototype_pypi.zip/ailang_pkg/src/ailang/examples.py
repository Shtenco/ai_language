"""Built-in DSL and NL examples."""
from __future__ import annotations
import textwrap
from typing import Dict, List

EXAMPLES: Dict[int, Dict[str, str]] = {
    1: {
        "title": "Basic Arithmetic & Control Flow",
        "dsl": textwrap.dedent("""\
            program Demo
            let x = 10
            let y = 20
            func add(a, b):
                return a + b
            let z = add(x, y)
            print "sum="
            print z
            if z > 20:
                print "big"
            else:
                print "small"
            repeat 3:
                print z
        """),
    },
    2: {
        "title": "Fibonacci (unrolled)",
        "dsl": textwrap.dedent("""\
            program Fibonacci
            print "Fibonacci:"
            let a = 0
            let b = 1
            print a
            print b
            let c = a + b
            print c
            let a = b
            let b = c
            let c = a + b
            print c
            let a = b
            let b = c
            let c = a + b
            print c
        """),
    },
    3: {
        "title": "Circle Area",
        "dsl": textwrap.dedent("""\
            program CircleArea
            func area(r):
                return 3.14159 * r * r
            let radius = 7
            let result = area(radius)
            print "Circle area:"
            print result
            if result > 100:
                print "Large circle"
            else:
                print "Small circle"
        """),
    },
    4: {
        "title": "Power & Repeat",
        "dsl": textwrap.dedent("""\
            program PowerDemo
            func square(x):
                return x * x
            let base = 5
            let sq = square(base)
            print "square ="
            print sq
            repeat 4:
                print base
        """),
    },
    5: {
        "title": "Nested If / Score",
        "dsl": textwrap.dedent("""\
            program NestedIf
            let score = 85
            if score >= 90:
                print "Excellent"
            else:
                if score >= 70:
                    print "Good"
                else:
                    print "Needs work"
        """),
    },
}

NL_EXAMPLES: Dict[str, List[str]] = {
    "ru": [
        "Напиши программу которая вычисляет квадрат числа 9 и выводит результат",
        "Создай функцию которая принимает два числа и возвращает их произведение. Вызови её с числами 6 и 7",
        "Напиши программу которая выводит слово Привет пять раз",
        "Вычисли периметр прямоугольника со сторонами 8 и 12",
        "Напиши функцию куб числа. Вычисли куб числа 4 и выведи результат",
    ],
    "en": [
        "Write a program that computes the square of 9 and prints the result",
        "Create a function that multiplies two numbers. Call it with 6 and 7 and print the result",
        "Print the word Hello five times using a loop",
        "Calculate the perimeter of a rectangle with sides 8 and 12",
        "Write a function that computes the cube of a number. Compute the cube of 4 and print it",
    ],
}
