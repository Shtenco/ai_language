"""
API-key management.
Priority: set_api_key() > GROK_API_KEY env > ~/.ailang/config.json
"""
from __future__ import annotations

import json
import os
from pathlib import Path

_CONFIG_DIR  = Path.home() / ".ailang"
_CONFIG_FILE = _CONFIG_DIR / "config.json"
_runtime_key: str = ""


def set_api_key(key: str) -> None:
    """Set API key for the current Python session (not persisted to disk)."""
    global _runtime_key
    _runtime_key = key.strip()


def get_api_key() -> str:
    """Return active API key (runtime > env > config file)."""
    if _runtime_key:
        return _runtime_key
    env = os.environ.get("GROK_API_KEY", "").strip()
    if env:
        return env
    return load_config().get("grok_api_key", "")


def load_config() -> dict:
    try:
        with open(_CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def save_config(data: dict) -> None:
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    existing = load_config()
    existing.update(data)
    with open(_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(existing, f, indent=2, ensure_ascii=False)


def save_api_key(key: str) -> None:
    """Persist API key to ~/.ailang/config.json."""
    save_config({"grok_api_key": key.strip()})


def clear_api_key() -> None:
    cfg = load_config()
    cfg.pop("grok_api_key", None)
    save_config(cfg)


def config_summary() -> str:
    lines = [f"Config file : {_CONFIG_FILE}"]
    key = get_api_key()
    if key:
        masked = key[:8] + "..." + key[-4:] if len(key) > 12 else "***"
        source = (
            "runtime (set_api_key)"  if _runtime_key                           else
            "env: GROK_API_KEY"      if os.environ.get("GROK_API_KEY", "")     else
            "~/.ailang/config.json"
        )
        lines.append(f"API key     : {masked}  (source: {source})")
    else:
        lines.append("API key     : ⚠️  NOT SET")
        lines.append("  → export GROK_API_KEY=xai-YOUR_KEY")
        lines.append("  → ailang config --set-key xai-YOUR_KEY")
        lines.append("  Get key at: https://console.x.ai")
    return "\n".join(lines)
