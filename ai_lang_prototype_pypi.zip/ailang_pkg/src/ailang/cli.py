"""CLI entry point: `ailang` command."""
from __future__ import annotations
import argparse, json, sys, textwrap

from . import __version__
from .ast_nodes import to_dict as ast_to_dict
from .codegen   import GENERATORS
from .config    import clear_api_key, config_summary, get_api_key, save_api_key, set_api_key
from .examples  import EXAMPLES, NL_EXAMPLES
from .grok      import detect_language, nl_to_dsl
from .pipeline  import pipeline
from .repl      import DONATE_BTC, DONATE_ETH, run_repl

_DONATE = f"""
  💙 Support / Поддержать:

  ETH: {DONATE_ETH}
  BTC: {DONATE_BTC}

  Thank you! 🙏
"""


def main(argv=None):
    p = _build()
    args = p.parse_args(argv)
    if hasattr(args, "key") and args.key:
        set_api_key(args.key)
    if not hasattr(args, "func"):
        p.print_help(); return
    args.func(args)


# ── repl ──────────────────────────────────────────────────────────────────────
def _repl(args):
    if args.key: set_api_key(args.key)
    run_repl()

# ── run ───────────────────────────────────────────────────────────────────────
def _run(args):
    if args.key: set_api_key(args.key)
    verbose = not args.quiet
    dsl_src = None; lang = "en"

    if args.example:
        ex = EXAMPLES.get(args.example)
        if not ex: _die(f"❌ Unknown example {args.example}. Valid: {list(EXAMPLES)}")
        _p(verbose, f"\n📚 Example {args.example}: {ex['title']}")
        dsl_src = ex["dsl"]
    elif args.dsl:
        try:
            with open(args.dsl, "r", encoding="utf-8") as f: dsl_src = f.read()
        except FileNotFoundError: _die(f"❌ File not found: {args.dsl}")
    elif args.nl:
        lang = detect_language(args.nl)
        try: dsl_src = nl_to_dsl(args.nl, verbose=verbose)
        except RuntimeError as e: _die(str(e))
        _p(verbose, f"\n── DSL ──\n{dsl_src}")
    elif args.nl_example:
        nl_lang, nl_idx_s = args.nl_example; nl_idx = int(nl_idx_s); lang = nl_lang
        pool = NL_EXAMPLES.get(nl_lang, NL_EXAMPLES["en"])
        if nl_idx >= len(pool): _die(f"❌ Index out of range (0–{len(pool)-1})")
        _p(verbose, f"\n📝 NL [{nl_lang}]: {pool[nl_idx]}")
        try: dsl_src = nl_to_dsl(pool[nl_idx], verbose=verbose)
        except RuntimeError as e: _die(str(e))
        _p(verbose, f"\n── DSL ──\n{dsl_src}")
    else:
        _die("❌ Specify a source: --example N | --dsl FILE | --nl TEXT | --nl-example LANG N")

    if not dsl_src or not dsl_src.strip(): _die("❌ Empty DSL.")

    result = pipeline(dsl_src, target=args.target, run=args.run,
                      compile_nat=args.compile_native,
                      graph_json=args.graph_json or "", ast_json=args.ast_json or "",
                      explain=args.explain, lang=lang, verbose=verbose)

    if args.out and "code" in result:
        with open(args.out, "w", encoding="utf-8") as f: f.write(result["code"])
        _p(verbose, f"\n💾 Saved → {args.out}")

    if args.show_tokens and "tokens" in result:
        print("\n── Tokens ──"); [print(f"  {t}") for t in result["tokens"]]
    if args.show_graph and "graph" in result:
        print("\n── Semantic Graph ──"); print(result["graph"].summary())
    if args.show_ast and "ast" in result:
        print("\n── AST ──"); print(json.dumps(ast_to_dict(result["ast"]), ensure_ascii=False, indent=2))
    if result.get("error"):
        print(f"\n⚠️  {result['error']}", file=sys.stderr); sys.exit(1)

# ── examples ──────────────────────────────────────────────────────────────────
def _examples(_):
    print("\n📚 DSL examples  (ailang run --example N)")
    for k, v in EXAMPLES.items(): print(f"  {k}: {v['title']}")
    print("\n🇷🇺 NL RU  (ailang run --nl-example ru N)")
    for i, e in enumerate(NL_EXAMPLES["ru"]): print(f"  {i}: {e}")
    print("\n🇬🇧 NL EN  (ailang run --nl-example en N)")
    for i, e in enumerate(NL_EXAMPLES["en"]): print(f"  {i}: {e}")
    print()

# ── config ────────────────────────────────────────────────────────────────────
def _config(args):
    if args.set_key:
        save_api_key(args.set_key); set_api_key(args.set_key)
        k = args.set_key; print(f"✅ Saved: {k[:8]}...{k[-4:]}"); return
    if args.clear_key:
        clear_api_key(); print("✅ Key removed."); return
    print(config_summary())

# ── donate ────────────────────────────────────────────────────────────────────
def _donate(_): print(_DONATE)

# ── parser ────────────────────────────────────────────────────────────────────
def _build() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(
        prog="ailang", description="AI Lang Prototype · Grok Edition",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""
        examples:
          ailang repl
          ailang run --example 1 --run
          ailang run --nl "вычисли куб числа 4" --run --explain
          ailang run --nl "write a function that squares a number" --target rust
          ailang run --nl-example ru 0 --run
          ailang run --example 3 --target c --compile-native
          ailang config --set-key xai-YOUR_KEY
          ailang examples
          ailang donate
        """),
    )
    root.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    subs = root.add_subparsers(dest="command")

    # repl
    pr = subs.add_parser("repl", help="Interactive REPL")
    pr.add_argument("--key", metavar="KEY"); pr.set_defaults(func=_repl)

    # run
    p2 = subs.add_parser("run", help="Run pipeline once",
                          formatter_class=argparse.RawDescriptionHelpFormatter)
    src = p2.add_mutually_exclusive_group()
    src.add_argument("--example",    type=int, metavar="N")
    src.add_argument("--dsl",        metavar="FILE")
    src.add_argument("--nl",         metavar="TEXT")
    src.add_argument("--nl-example", nargs=2, metavar=("LANG","N"))
    p2.add_argument("--key",            metavar="KEY")
    p2.add_argument("--target",         default="python", choices=list(GENERATORS))
    p2.add_argument("--run",            action="store_true")
    p2.add_argument("--compile-native", action="store_true")
    p2.add_argument("--explain",        action="store_true")
    p2.add_argument("--out",            metavar="FILE")
    p2.add_argument("--graph-json",     metavar="FILE")
    p2.add_argument("--ast-json",       metavar="FILE")
    p2.add_argument("--show-tokens",    action="store_true")
    p2.add_argument("--show-graph",     action="store_true")
    p2.add_argument("--show-ast",       action="store_true")
    p2.add_argument("--quiet",          action="store_true")
    p2.set_defaults(func=_run)

    # examples
    pe = subs.add_parser("examples", help="List built-in examples")
    pe.set_defaults(func=_examples)

    # config
    pc = subs.add_parser("config", help="Manage API key")
    cg = pc.add_mutually_exclusive_group()
    cg.add_argument("--set-key",   metavar="KEY")
    cg.add_argument("--clear-key", action="store_true")
    cg.add_argument("--show",      action="store_true")
    pc.set_defaults(func=_config)

    # donate
    pd = subs.add_parser("donate", help="Donation addresses")
    pd.set_defaults(func=_donate)

    return root


def _p(v, m):
    if v: print(m)

def _die(m):
    print(m, file=sys.stderr); sys.exit(1)
