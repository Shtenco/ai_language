"""AST dataclasses + JSON serializer."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class AstNode:
    kind: str = field(default="", init=False)

@dataclass
class ProgramNode(AstNode):
    name: str; body: List[AstNode]
    def __post_init__(self): self.kind = "Program"

@dataclass
class LetNode(AstNode):
    var: str; expr: str
    def __post_init__(self): self.kind = "Let"

@dataclass
class FuncNode(AstNode):
    name: str; args: List[str]; body: List[AstNode]
    def __post_init__(self): self.kind = "Func"

@dataclass
class ReturnNode(AstNode):
    expr: str
    def __post_init__(self): self.kind = "Return"

@dataclass
class PrintNode(AstNode):
    expr: str
    def __post_init__(self): self.kind = "Print"

@dataclass
class IfNode(AstNode):
    cond: str; then_body: List[AstNode]; else_body: List[AstNode]
    def __post_init__(self): self.kind = "If"

@dataclass
class RepeatNode(AstNode):
    count: str; body: List[AstNode]
    def __post_init__(self): self.kind = "Repeat"

@dataclass
class ExprNode(AstNode):
    expr: str
    def __post_init__(self): self.kind = "Expr"


def to_dict(node: AstNode) -> Dict[str, Any]:
    if isinstance(node, ProgramNode):
        return {"kind": "Program", "name": node.name, "body": [to_dict(n) for n in node.body]}
    if isinstance(node, LetNode):
        return {"kind": "Let", "var": node.var, "expr": node.expr}
    if isinstance(node, FuncNode):
        return {"kind": "Func", "name": node.name, "args": node.args,
                "body": [to_dict(n) for n in node.body]}
    if isinstance(node, ReturnNode):
        return {"kind": "Return", "expr": node.expr}
    if isinstance(node, PrintNode):
        return {"kind": "Print", "expr": node.expr}
    if isinstance(node, IfNode):
        return {"kind": "If", "cond": node.cond,
                "then": [to_dict(n) for n in node.then_body],
                "else": [to_dict(n) for n in node.else_body]}
    if isinstance(node, RepeatNode):
        return {"kind": "Repeat", "count": node.count,
                "body": [to_dict(n) for n in node.body]}
    if isinstance(node, ExprNode):
        return {"kind": "Expr", "expr": node.expr}
    return {"kind": "Unknown"}
