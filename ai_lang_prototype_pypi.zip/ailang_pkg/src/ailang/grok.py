"""Grok API (xAI) client — key resolved from ailang.config."""
from __future__ import annotations

import json
import re
from typing import Dict, List

try:
    import requests as _req
except ImportError:
    import os, sys
    os.system(f"{sys.executable} -m pip install requests --quiet")
    import requests as _req  # type: ignore

from .config import get_api_key

GROK_URL   = "https://api.x.ai/v1/chat/completions"
GROK_MODEL = "grok-4-fast"

_DSL_REF = """
DSL Reference (indentation = 4 spaces):
  program <name>
  let <var> = <expr>
  func <name>(<arg1>, <arg2>):
      let <local> = <expr>
      return <expr>
  let <var> = <funcname>(<arg1>, <arg2>)
  print <var>
  print "string"
  if <condition>:
      <body>
  else:
      <body>
  repeat <N>:
      <body>
Rules:
  - No semicolons, no type declarations
  - Strings in double quotes only
  - Arithmetic: +  -  *  /  **  %
  - Comparisons: >  <  >=  <=  ==  !=
  - ONE expression per line
  - Output ONLY the DSL — no explanation, no markdown fences
"""

_SYS_NL2DSL = (
    "You are a compiler front-end. Translate a natural language program description "
    "(English or Russian) into the exact DSL below. "
    "Output ONLY valid DSL — no explanation, no markdown backticks.\n\n" + _DSL_REF
)

_SYS_DEBUG = (
    "You are a DSL debugger. Given broken DSL and an error, output ONLY the fixed DSL. "
    "No explanation, no markdown.\n\n" + _DSL_REF
)


def _headers() -> Dict[str, str]:
    key = get_api_key()
    if not key:
        raise RuntimeError(
            "Grok API key not set.\n"
            "  export GROK_API_KEY=xai-YOUR_KEY\n"
            "  ailang config --set-key xai-YOUR_KEY\n"
            "  ailang run --key xai-YOUR_KEY ...\n"
            "  Get key at: https://console.x.ai"
        )
    return {
        "Authorization": f"Bearer {key}",
        "Content-Type":  "application/json",
        "HTTP-Referer":  "https://pypi.org/project/ai-lang-prototype",
        "X-Title":       "AI Lang Prototype",
    }


def grok_call(
    messages:    List[Dict],
    temperature: float = 0.3,
    max_tokens:  int   = 1024,
    label:       str   = "?",
) -> str:
    """Single entry point for all Grok API calls."""
    payload = {
        "model":       GROK_MODEL,
        "messages":    messages,
        "max_tokens":  max_tokens,
        "temperature": temperature,
    }
    try:
        resp = _req.post(
            GROK_URL,
            headers=_headers(),
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            timeout=60,
        )
        if resp.status_code != 200:
            return f"[ERROR HTTP {resp.status_code}]: {resp.text[:300]}"
        data = resp.json()
        if "choices" not in data:
            return f"[ERROR]: {data.get('error',{}).get('message', str(data))[:200]}"
        return data["choices"][0]["message"]["content"].strip()
    except RuntimeError:
        raise
    except Exception as exc:
        return f"[ERROR]: {exc}"


def detect_language(text: str) -> str:
    """'ru' if ≥10% Cyrillic characters, else 'en'."""
    cyr = sum(1 for c in text if "\u0400" <= c <= "\u04FF")
    return "ru" if cyr >= max(1, len(text) * 0.10) else "en"


def nl_to_dsl(text: str, verbose: bool = True) -> str:
    """Natural language (RU/EN) → DSL via Grok."""
    lang = detect_language(text)
    if verbose:
        flag = "🇷🇺" if lang == "ru" else "🇬🇧"
        print(f"{flag} Language: {'Russian' if lang=='ru' else 'English'}")
        print("🤖 Grok: NL → DSL ...")
    raw = grok_call(
        [{"role": "system", "content": _SYS_NL2DSL},
         {"role": "user",   "content": text}],
        temperature=0.15, max_tokens=1024, label="NL→DSL",
    )
    dsl = re.sub(r"```[a-z]*\n?", "", raw).strip("`").strip()
    if verbose:
        print(f"✅ DSL ready ({len(dsl.splitlines())} lines)\n")
    return dsl


def grok_explain(code: str, lang: str = "en") -> str:
    language = "Russian" if lang == "ru" else "English"
    return grok_call(
        [{"role": "system",
          "content": (f"You are a helpful programming tutor. Explain the following "
                      f"generated code in plain {language}. Be concise (4-6 sentences).")},
         {"role": "user", "content": code}],
        temperature=0.5, max_tokens=600, label="EXPLAIN",
    )


def grok_self_debug(dsl: str, error: str) -> str:
    raw = grok_call(
        [{"role": "system", "content": _SYS_DEBUG},
         {"role": "user",
          "content": f"DSL:\n{dsl}\n\nError: {error}\n\nFixed DSL:"}],
        temperature=0.1, max_tokens=1024, label="DEBUG",
    )
    return re.sub(r"```[a-z]*\n?", "", raw).strip("`").strip()
