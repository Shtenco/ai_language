"""DSL Tokenizer."""
from __future__ import annotations

import re
from typing import Any, List, Tuple

TokenList = List[Tuple[str, Any]]


def tokenize(source: str) -> TokenList:
    tokens: TokenList = []
    indent_stack = [0]

    for raw_line in source.splitlines():
        stripped = raw_line.lstrip()
        if not stripped or stripped.startswith("#"):
            continue

        indent  = len(raw_line) - len(stripped)
        content = stripped.rstrip()

        if indent > indent_stack[-1]:
            tokens.append(("INDENT", indent))
            indent_stack.append(indent)
        while indent < indent_stack[-1]:
            tokens.append(("DEDENT", indent_stack.pop()))

        if content.startswith("program "):
            tokens.append(("PROGRAM", content[8:].strip()))
        elif content.startswith("let "):
            rest = content[4:].strip()
            var, expr = rest.split("=", 1) if "=" in rest else (rest, "")
            tokens.append(("LET", (var.strip(), expr.strip())))
        elif content.startswith("func "):
            head = content[5:].strip().rstrip(":")
            m = re.match(r"(\w+)\(([^)]*)\)", head)
            name = m.group(1) if m else head
            args = [a.strip() for a in m.group(2).split(",") if a.strip()] if m else []
            tokens.append(("FUNC", (name, args)))
        elif content.startswith("return "):
            tokens.append(("RETURN", content[7:].strip()))
        elif content.startswith("print "):
            tokens.append(("PRINT", content[6:].strip()))
        elif content.startswith("if "):
            tokens.append(("IF", content[3:].strip().rstrip(":")))
        elif content in ("else:", "else"):
            tokens.append(("ELSE", None))
        elif content.startswith("repeat "):
            tokens.append(("REPEAT", content[7:].strip().rstrip(":")))
        else:
            tokens.append(("EXPR", content))

        tokens.append(("NEWLINE", None))

    while len(indent_stack) > 1:
        tokens.append(("DEDENT", indent_stack.pop()))
    tokens.append(("EOF", None))
    return tokens
