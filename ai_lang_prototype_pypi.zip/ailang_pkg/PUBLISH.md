# Публикация на PyPI — пошаговая инструкция

## 1. Установи инструменты

```bash
pip install build twine
```

---

## 2. Зарегистрируйся на PyPI

Перейди на https://pypi.org/account/register/ и создай аккаунт.

После регистрации:
→ Account Settings → API tokens → Add API token
- Token name: ailang-upload
- Scope: Entire account

**Скопируй токен** — выглядит как `pypi-AgEIp...` — он показывается ОДИН РАЗ!

---

## 3. Сохрани токен в ~/.pypirc

Создай файл `~/.pypirc` (Windows: `C:\Users\ВАШ_ИМЯ\.pypirc`):

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-ТВОЙ_ТОКЕН_ЗДЕСЬ

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-ТЕСТОВЫЙ_ТОКЕН_ЗДЕСЬ
```

---

## 4. Залей проект на GitHub

```bash
cd ai-lang-prototype

git init
git remote add origin https://github.com/Shtenco/ai_language.git
git add .
git commit -m "Initial release v1.0.0"
git branch -M main
git push -u origin main
```

---

## 5. Тест на test.pypi.org (рекомендуется)

```bash
python -m build
twine upload --repository testpypi dist/*

# Проверь установку:
pip install --index-url https://test.pypi.org/simple/ ai-lang-prototype
ailang --version
```

---

## 6. Публикация на настоящем PyPI

```bash
twine upload dist/*
```

Через 1–2 минуты работает:

```bash
pip install ai-lang-prototype
ailang --version
ailang repl
```

---

## 7. Обновление версии

Поменяй в двух местах:
- `pyproject.toml` → `version = "1.0.1"`
- `src/ailang/__init__.py` → `__version__ = "1.0.1"`

Затем:

```bash
python -m build
twine upload dist/*
git tag v1.0.1
git push origin v1.0.1
```

---

## 8. Автопубликация через GitHub Actions

Файл `.github/workflows/publish.yml` уже включён в проект.

Добавь секрет в GitHub:
→ Settings → Secrets and variables → Actions → New repository secret
- Name:  `PYPI_TOKEN`
- Value: твой PyPI токен

После этого достаточно запушить тег:

```bash
git tag v1.0.1
git push origin v1.0.1
```

И пакет автоматически опубликуется на PyPI.

---

## Структура проекта

```
ai-lang-prototype/
├── src/ailang/
│   ├── __init__.py      ← public API
│   ├── config.py        ← управление ключом
│   ├── grok.py          ← Grok API
│   ├── tokenizer.py
│   ├── ast_nodes.py
│   ├── parser.py
│   ├── semantic.py
│   ├── pipeline.py
│   ├── runner.py
│   ├── examples.py
│   ├── repl.py
│   ├── cli.py           ← команда ailang
│   └── codegen/         ← Python C Rust Solidity Kotlin
├── tests/
│   └── test_pipeline.py ← 37 тестов
├── .github/workflows/
│   └── publish.yml      ← автопубликация
├── pyproject.toml       ← манифест пакета
├── README.md
├── LICENSE
├── MANIFEST.in
├── .gitignore
└── PUBLISH.md           ← этот файл
```
