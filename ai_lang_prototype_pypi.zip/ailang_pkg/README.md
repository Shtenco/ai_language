# AI Lang Prototype 🧠

> **Natural Language → DSL → AST → Semantic Graph → Code**
> Powered by **Grok API (xAI)** · Generates **Python / C / Rust / Solidity / Kotlin**

```
[English / Russian text]
        ↓  Grok API (xAI)
      [DSL]
        ↓  Tokenizer → Parser
      [AST]
        ↓  Semantic Graph
  [Code Generator]
        ↓
Python / C / Rust / Solidity / Kotlin
        ↓
    Run / Compile
```

---

## Install

```bash
pip install ai-lang-prototype
```

---

## Quick Start

### 1. Set your Grok API key

Get your key at → **[https://console.x.ai](https://console.x.ai)**

```bash
# Option A — environment variable (recommended)
export GROK_API_KEY="xai-YOUR_KEY_HERE"

# Option B — save permanently to ~/.ailang/config.json
ailang config --set-key xai-YOUR_KEY_HERE

# Option C — pass inline per command
ailang run --key xai-YOUR_KEY_HERE --nl "compute the cube of 4"
```

### 2. Interactive REPL

```bash
ailang repl
```

Type tasks in **Russian or English** — Grok translates them into DSL,
then all pipeline stages run automatically.

### 3. CLI Examples

```bash
# Built-in examples (no API key needed)
ailang run --example 1 --target python --run
ailang run --example 3 --target c

# Natural language → Python → run + explain
ailang run --nl "вычисли факториал числа 5" --run --explain
ailang run --nl "write a function that squares a number" --target rust

# Preset NL examples
ailang run --nl-example ru 0 --run
ailang run --nl-example en 2 --target kotlin

# Save outputs
ailang run --example 1 --out demo.py --graph-json g.json --ast-json ast.json

# List all examples
ailang examples

# Donate / support
ailang donate
```

### 4. Python API

```python
from ailang import pipeline, nl_to_dsl, set_api_key

set_api_key("xai-YOUR_KEY_HERE")

dsl    = nl_to_dsl("compute the square of 9 and print the result")
result = pipeline(dsl, target="python", run=True)

print(result["code"])    # generated Python code
print(result["output"])  # execution output
```

---

## DSL Reference

```
program <n>
let <var> = <expr>
func <n>(<arg1>, <arg2>):
    return <expr>
let <r> = <funcname>(<arg1>, <arg2>)
print <var>
print "string"
if <condition>:
    <body>
else:
    <body>
repeat <N>:
    <body>
```

---

## Supported Targets

| Target     | Generator | Run  | Native Compile  |
|------------|-----------|------|-----------------|
| `python`   | ✅        | ✅   | —               |
| `c`        | ✅        | —    | ✅ `gcc`        |
| `rust`     | ✅        | —    | ✅ `rustc`      |
| `solidity` | ✅        | —    | ✅ `solc`       |
| `kotlin`   | ✅        | —    | ✅ `kotlinc`    |

---

## License

MIT © 2024 Evgeniy Koshtenko

---

## 💙 Support / Поддержать проект

If this project saved you time — a small donation keeps development going.

**Ethereum (ETH / ERC-20):**
```
0x980Ddb04c54979b3Ed23df4a7DBc7049b7d0D686
```

**Bitcoin (BTC / Native SegWit):**
```
bc1q49rfm0p6qh6nlnm4az4yhhk9x82zfxwgtcnhvm
```

Every contribution is genuinely appreciated. Thank you! 🙏

---

**Links:**
[PyPI](https://pypi.org/project/ai-lang-prototype) ·
[GitHub](https://github.com/Shtenco/ai_language) ·
[Grok API](https://console.x.ai) ·
[Author: Evgeniy Koshtenko](https://github.com/Shtenco)
